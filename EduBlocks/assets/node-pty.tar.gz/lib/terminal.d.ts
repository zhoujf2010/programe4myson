/// <reference types="node" />
import { Socket } from 'net';
import { EventEmitter } from 'events';
import { ITerminal, IPtyForkOptions } from './interfaces';
export declare abstract class Terminal implements ITerminal {
    protected static readonly DEFAULT_COLS: number;
    protected static readonly DEFAULT_ROWS: number;
    protected socket: Socket;
    protected pid: number;
    protected fd: number;
    protected pty: any;
    protected file: string;
    protected name: string;
    protected cols: number;
    protected rows: number;
    protected readable: boolean;
    protected writable: boolean;
    protected _internalee: EventEmitter;
    constructor(opt?: IPtyForkOptions);
    private _checkType(name, value, type);
    /** See net.Socket.end */
    end(data: string): void;
    /** See stream.Readable.pipe */
    pipe(dest: any, options: any): any;
    /** See net.Socket.pause */
    pause(): Socket;
    /** See net.Socket.resume */
    resume(): Socket;
    /** See net.Socket.setEncoding */
    setEncoding(encoding: string): void;
    addListener(eventName: string, listener: (...args: any[]) => any): void;
    on(eventName: string, listener: (...args: any[]) => any): void;
    emit(eventName: string, ...args: any[]): any;
    listeners(eventName: string): Function[];
    removeListener(eventName: string, listener: (...args: any[]) => any): void;
    removeAllListeners(eventName: string): void;
    once(eventName: string, listener: (...args: any[]) => any): void;
    abstract write(data: string): void;
    abstract resize(cols: number, rows: number): void;
    abstract destroy(): void;
    abstract kill(signal?: string): void;
    /**
     * Gets the name of the process.
     */
    readonly abstract process: string;
    redraw(): void;
    protected _close(): void;
    protected _parseEnv(env: {
        [key: string]: string;
    }): string[];
}
