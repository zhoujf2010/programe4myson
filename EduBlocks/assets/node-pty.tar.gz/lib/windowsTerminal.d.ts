import { Terminal } from './terminal';
import { IPtyForkOptions, IPtyOpenOptions } from './interfaces';
import { ArgvOrCommandLine } from './types';
export declare class WindowsTerminal extends Terminal {
    private isReady;
    private deferreds;
    private agent;
    constructor(file?: string, args?: ArgvOrCommandLine, opt?: IPtyForkOptions);
    /**
     * openpty
     */
    static open(options?: IPtyOpenOptions): void;
    /**
     * Events
     */
    write(data: string): void;
    /**
     * TTY
     */
    resize(cols: number, rows: number): void;
    destroy(): void;
    kill(signal?: string): void;
    private _defer(deferredFn);
    /**
     * Gets the name of the process.
     */
    readonly process: string;
}
