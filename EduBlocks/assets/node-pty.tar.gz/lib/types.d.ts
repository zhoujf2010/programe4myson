/**
 * Copyright (c) 2017, Daniel Imms (MIT License).
 */
export declare type ArgvOrCommandLine = string[] | string;
